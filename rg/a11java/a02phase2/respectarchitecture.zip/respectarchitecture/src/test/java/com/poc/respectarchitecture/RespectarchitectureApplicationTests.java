package com.poc.respectarchitecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RespectarchitectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
